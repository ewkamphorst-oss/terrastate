# Terrastate Solo

Eén bestand. Open `index.html` in de browser. Het spel bewaart je natie in die browser.

Stempel van deze build: **27 Sep 2026 · 00:21 · Update 1.0**

Client: `solo-2026-09-27a`

## Spelers

De update voor spelers zit in het spel (What’s new) en in `updates/first-game-update.pdf` (Update 1.0).

Deze beurt: landingbuit 5% met lagere plafonds; Swarm Drones, Ghost Squadrons en Titan Mechs getemperd; gevecht en voorraden weigeren kapotte getallen. Je bestaande save blijft.

## Itch.io

Upload `Terrastate-itch.zip`.

- Kind: HTML
- Het spel start op `index.html` in de wortel van de zip
- Zet “This file will be played in the browser” aan

## Newgrounds

Upload `Terrastate-newgrounds.zip`.

- HTML5
- `index.html` staat in de wortel, niet in een extra map

De itch-zip en de Newgrounds-zip zijn dezelfde spelbestanden.

## GitHub

1. Maak een lege repository. Vink README, .gitignore en license uit, anders weigert GitHub een upload over die bestanden.
2. Upload de inhoud van `Terrastate-github.zip`: `index.html`, de map `updates`, `README.md` en `Terrastate-ontwikkelaars.zip`.
3. Of pak uit, en push met git als je dat liever doet.

## Ontwikkelaars

De technische lijst zit alleen in `Terrastate-ontwikkelaars.zip` (één pdf). Die staat niet in het spel, en niet in de zip voor itch of Newgrounds.

## Telefoon

Voor op de telefoon: `Terrastate-phone-0021.zip`. Daarin heet het spel `Terrastate-0021.html`, niet `index.html`, zodat de telefoon niet een ouder bestand opent.
